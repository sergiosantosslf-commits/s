# Controle de Zona Quente — v5.3 Patch 4.2
Ferramenta web para verificar Zona Quente.
## Publicação
- Suba para GitHub e ative Pages.
## Estrutura
index.html, assets/css/styles.css, assets/js/app.js, assets/js/zona_quente.js, data/zona_quente.json
